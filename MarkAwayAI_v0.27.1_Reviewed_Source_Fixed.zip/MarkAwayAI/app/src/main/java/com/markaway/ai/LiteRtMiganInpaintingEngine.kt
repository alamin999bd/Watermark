package com.markaway.ai

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import com.google.ai.edge.litert.Accelerator
import com.google.ai.edge.litert.CompiledModel


/**
 * MI-GAN 512x512 inference adapter.
 *
 * The model asset is downloaded by the GitHub Actions workflow at build time.
 * Required path: app/src/main/assets/models/migan_fp16.tflite.
 *
 * Input contract:
 *   NCHW [1,4,512,512] = [mask - 0.5, R*mask, G*mask, B*mask]
 *   mask: 1 = keep, 0 = erase; RGB normalized to [-1,1]
 * Output contract: NCHW [1,3,512,512], normalized to [-1,1].
 */
object LiteRtMiganInpaintingEngine {
    private const val MODEL_ASSET = "models/migan_fp16.tflite"
    private const val SIZE = 512
    private const val PLANE = SIZE * SIZE
    private val modelLock = Any()
    @Volatile private var cachedModel: CompiledModel? = null

    fun isModelBundled(context: Context): Boolean =
        runCatching { context.assets.open(MODEL_ASSET).use { true } }.getOrDefault(false)

    /**
     * Runs offline inpainting. White pixels in eraseMask mark pixels to erase.
     * The complete image is resized to the 512×512 model canvas and restored to source dimensions.
     */
    fun repair(context: Context, source: Bitmap, eraseMask: Bitmap): Bitmap {
        require(source.width == eraseMask.width && source.height == eraseMask.height) {
            "Mask dimensions must match the source image"
        }
        check(isModelBundled(context)) {
            "MI-GAN model file is missing. Add models/migan_fp16.tflite before enabling AI repair."
        }

        // Resize the complete frame to the model canvas. This allows masks at any
        // normalized location (including corners), instead of silently ignoring
        // everything outside a centered square crop.
        val inputImage = Bitmap.createScaledBitmap(source, SIZE, SIZE, true)
        val inputMask = Bitmap.createScaledBitmap(eraseMask, SIZE, SIZE, true)

        try {
            val pixels = IntArray(PLANE)
            val maskPixels = IntArray(PLANE)
            inputImage.getPixels(pixels, 0, SIZE, 0, 0, SIZE, SIZE)
            inputMask.getPixels(maskPixels, 0, SIZE, 0, 0, SIZE, SIZE)

            // Model input is channel-first NCHW: mask-0.5, then masked RGB.
            val input = FloatArray(4 * PLANE)
            for (i in 0 until PLANE) {
                val color = pixels[i]
                val erase = (maskPixels[i] and 0xff) / 255f
                val keep = 1f - erase
                input[i] = keep - 0.5f
                input[PLANE + i] = (((color shr 16) and 0xff) / 127.5f - 1f) * keep
                input[2 * PLANE + i] = (((color shr 8) and 0xff) / 127.5f - 1f) * keep
                input[3 * PLANE + i] = ((color and 0xff) / 127.5f - 1f) * keep
            }

            // Keep the compiled model alive across video frames. Recompiling the
            // GPU model for every frame would make video processing impractical.
            val generated = synchronized(modelLock) {
                val compiled = cachedModel ?: CompiledModel.create(
                    context.assets,
                    MODEL_ASSET,
                    CompiledModel.Options(Accelerator.GPU),
                    null
                ).also { cachedModel = it }
                val inputs = compiled.createInputBuffers()
                val outputs = compiled.createOutputBuffers()
                try {
                    inputs[0].writeFloat(input)
                    compiled.run(inputs, outputs)
                    outputs[0].readFloat()
                } finally {
                    inputs.forEach { it.close() }
                    outputs.forEach { it.close() }
                }
            }
            check(generated.size >= 3 * PLANE) { "Unexpected MI-GAN output tensor size" }

            val repairedPixels = IntArray(PLANE)
            for (i in 0 until PLANE) {
                val original = pixels[i]
                val keep = 1f - ((maskPixels[i] and 0xff) / 255f)
                val rGen = ((generated[i] + 1f) * 127.5f).coerceIn(0f, 255f)
                val gGen = ((generated[PLANE + i] + 1f) * 127.5f).coerceIn(0f, 255f)
                val bGen = ((generated[2 * PLANE + i] + 1f) * 127.5f).coerceIn(0f, 255f)
                val r = ((((original shr 16) and 0xff) * keep) + rGen * (1f - keep)).toInt().coerceIn(0, 255)
                val g = ((((original shr 8) and 0xff) * keep) + gGen * (1f - keep)).toInt().coerceIn(0, 255)
                val b = (((original and 0xff) * keep) + bGen * (1f - keep)).toInt().coerceIn(0, 255)
                repairedPixels[i] = (0xff shl 24) or (r shl 16) or (g shl 8) or b
            }

            val repairedSquare = Bitmap.createBitmap(repairedPixels, SIZE, SIZE, Bitmap.Config.ARGB_8888)
            try {
                val repairedFull = Bitmap.createScaledBitmap(repairedSquare, source.width, source.height, true)
                try {
                    val result = source.copy(Bitmap.Config.ARGB_8888, true)
                        ?: error("Could not create output bitmap")
                    Canvas(result).drawBitmap(repairedFull, 0f, 0f, null)
                    return result
                } finally {
                    if (!repairedFull.isRecycled) repairedFull.recycle()
                }
            } finally {
                if (!repairedSquare.isRecycled) repairedSquare.recycle()
            }
        } finally {
            if (!inputImage.isRecycled) inputImage.recycle()
            if (!inputMask.isRecycled) inputMask.recycle()
        }
    }
}
