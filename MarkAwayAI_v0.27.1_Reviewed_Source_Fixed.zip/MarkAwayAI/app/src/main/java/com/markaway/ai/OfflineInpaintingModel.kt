package com.markaway.ai

import android.content.Context

/**
 * Compatibility facade for the app's offline inpainting model check.
 * Inference is implemented by LiteRtMiganInpaintingEngine; this class does not
 * create a legacy TensorFlow Lite Interpreter.
 */
@Deprecated("Use LiteRtMiganInpaintingEngine directly")
object OfflineInpaintingModel {
    fun isModelBundled(context: Context): Boolean =
        LiteRtMiganInpaintingEngine.isModelBundled(context)
}
