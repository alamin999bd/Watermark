package com.markaway.ai

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFprobeKit
import com.arthenica.ffmpegkit.ReturnCode
import java.io.File
import java.util.Locale
import kotlin.math.max

/**
 * Offline, frame-by-frame video watermark inpainting.
 *
 * Pipeline:
 * 1) FFmpeg decodes a CFR frame sequence from the selected video.
 * 2) MI-GAN repairs the selected normalized region in each frame.
 * 3) FFmpeg encodes the repaired frames and remuxes the original audio.
 *
 * The current UI supplies one fixed normalized rectangle. This is suitable for a
 * stationary watermark; automatic moving-watermark tracking/keyframes are not yet
 * implemented and must not be represented as supported.
 */
object VideoAiRemovalEngine {
    private const val MAX_CLIP_SECONDS = 20.0
    private const val MAX_FPS = 30
    private const val MAX_WIDTH = 1280
    private val mainHandler = Handler(Looper.getMainLooper())

    fun start(
        context: Context,
        inputUri: Uri,
        centerX: Float,
        centerY: Float,
        widthFraction: Float,
        onProgress: (String) -> Unit,
        onDone: (Boolean, String) -> Unit
    ) {
        Thread {
            val workDir = File(context.cacheDir, "markaway_video_ai_${System.currentTimeMillis()}")
            try {
                check(LiteRtMiganInpaintingEngine.isModelBundled(context)) {
                    "MI-GAN model is missing. Build the APK with the model asset first."
                }
                workDir.mkdirs()
                val inputFile = File(workDir, "source.mp4")
                context.contentResolver.openInputStream(inputUri)?.use { source ->
                    inputFile.outputStream().use { target -> source.copyTo(target) }
                } ?: error("Cannot read the selected video")

                val durationText = probe(inputFile.absolutePath,
                    "-v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1")
                val duration = durationText.trim().toDoubleOrNull()
                    ?: error("Could not read video duration")
                require(duration > 0.0) { "The selected video has no valid duration" }
                require(duration <= MAX_CLIP_SECONDS) {
                    "For reliable on-device AI processing, choose a clip of ${MAX_CLIP_SECONDS.toInt()} seconds or less."
                }

                val fpsText = probe(inputFile.absolutePath,
                    "-v error -select_streams v:0 -show_entries stream=avg_frame_rate -of default=noprint_wrappers=1:nokey=1")
                val sourceFps = parseRate(fpsText.trim()).coerceIn(1.0, MAX_FPS.toDouble())
                val fps = String.format(Locale.US, "%.3f", sourceFps)

                val framesDir = File(workDir, "frames").apply { mkdirs() }
                val repairedDir = File(workDir, "repaired").apply { mkdirs() }
                postProgress(onProgress, "Decoding video frames…")
                val extractCommand = "-y -i ${quote(inputFile.absolutePath)} " +
                    "-vf \"fps=$fps,scale='trunc(min($MAX_WIDTH,iw)/2)*2':-2\" -vsync 0 " +
                    "${quote(File(framesDir, "frame_%06d.png").absolutePath)}"
                runFfmpeg(extractCommand, "Video frame decoding failed")

                val frames = framesDir.listFiles { f -> f.isFile && f.name.endsWith(".png") }
                    ?.sortedBy { it.name } ?: emptyList()
                require(frames.isNotEmpty()) { "No video frames were decoded" }

                val normalizedX = centerX.coerceIn(0.02f, 0.98f)
                val normalizedY = centerY.coerceIn(0.02f, 0.98f)
                val normalizedWidth = widthFraction.coerceIn(0.05f, 0.8f)

                frames.forEachIndexed { index, frameFile ->
                    val frame = BitmapFactory.decodeFile(frameFile.absolutePath)
                        ?: error("Could not decode frame ${index + 1}")
                    var mask: Bitmap? = null
                    var repaired: Bitmap? = null
                    try {
                        mask = createMask(frame.width, frame.height, normalizedX, normalizedY, normalizedWidth)
                        repaired = LiteRtMiganInpaintingEngine.repair(context, frame, mask)
                        val destination = File(repairedDir, frameFile.name)
                        destination.outputStream().use { stream ->
                            check(repaired.compress(Bitmap.CompressFormat.PNG, 100, stream)) {
                                "Could not save repaired frame ${index + 1}"
                            }
                        }
                    } finally {
                        if (repaired != null && !repaired.isRecycled) repaired.recycle()
                        if (mask != null && !mask.isRecycled) mask.recycle()
                        if (!frame.isRecycled) frame.recycle()
                    }
                    if (index % 5 == 0 || index == frames.lastIndex) {
                        val percent = ((index + 1) * 100 / frames.size)
                        postProgress(onProgress, "AI repairing frames: $percent% (${index + 1}/${frames.size})")
                    }
                }

                val outputFile = File(workDir, "markaway_ai_output.mp4")
                postProgress(onProgress, "Encoding repaired video and restoring audio…")
                val encodeCommand = "-y -framerate $fps -i ${quote(File(repairedDir, "frame_%06d.png").absolutePath)} " +
                    "-i ${quote(inputFile.absolutePath)} -map 0:v:0 -map 1:a? " +
                    "-c:v mpeg4 -q:v 3 -pix_fmt yuv420p -c:a aac -b:a 128k " +
                    "-t ${String.format(Locale.US, "%.3f", duration)} -movflags +faststart ${quote(outputFile.absolutePath)}"
                runFfmpeg(encodeCommand, "Could not encode the repaired MP4")

                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, "MarkAway_AI_Removed_${System.currentTimeMillis()}.mp4")
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/MarkAway")
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }
                val outputUri = context.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                    ?: error("Could not create output video in Gallery")
                try {
                    context.contentResolver.openOutputStream(outputUri)?.use { target ->
                        outputFile.inputStream().use { source -> source.copyTo(target) }
                    } ?: error("Could not open output video")
                    val publish = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
                    check(context.contentResolver.update(outputUri, publish, null, null) > 0) {
                        "Could not publish output video"
                    }
                } catch (e: Exception) {
                    context.contentResolver.delete(outputUri, null, null)
                    throw e
                }
                postDone(onDone, true,
                    "AI video saved to Movies/MarkAway. A fixed selected area was reconstructed frame by frame; moving-watermark tracking is not included.")
            } catch (e: Exception) {
                postDone(onDone, false, "Video AI Removal failed: ${e.message ?: "unknown error"}")
            } finally {
                workDir.deleteRecursively()
            }
        }.start()
    }

    private fun createMask(
        width: Int, height: Int, centerX: Float, centerY: Float, widthFraction: Float
    ): Bitmap {
        val mask = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(mask)
        canvas.drawColor(android.graphics.Color.BLACK)
        val boxWidth = (width * widthFraction).coerceIn(8f, width.toFloat())
        val boxHeight = (boxWidth * 0.40f).coerceIn(8f, height.toFloat())
        val cx = width * centerX
        val cy = height * centerY
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.WHITE }
        canvas.drawRoundRect(
            cx - boxWidth / 2f, cy - boxHeight / 2f,
            cx + boxWidth / 2f, cy + boxHeight / 2f,
            max(2f, boxHeight * 0.06f), max(2f, boxHeight * 0.06f), paint
        )
        return mask
    }

    private fun probe(path: String, args: String): String {
        val session = FFprobeKit.execute("$args ${quote(path)}")
        check(ReturnCode.isSuccess(session.returnCode)) {
            "Could not inspect the video: ${session.failStackTrace ?: session.output}"
        }
        return session.output.orEmpty()
    }

    private fun runFfmpeg(command: String, message: String) {
        val session = FFmpegKit.execute(command)
        check(ReturnCode.isSuccess(session.returnCode)) {
            "$message: ${session.failStackTrace ?: session.output.orEmpty().takeLast(500)}"
        }
    }

    private fun parseRate(value: String): Double {
        val parts = value.split("/")
        if (parts.size == 2) {
            val numerator = parts[0].toDoubleOrNull() ?: return 30.0
            val denominator = parts[1].toDoubleOrNull() ?: return 30.0
            if (denominator != 0.0) return numerator / denominator
        }
        return value.toDoubleOrNull() ?: 30.0
    }

    private fun quote(path: String): String = "'" + path.replace("'", "'\\''") + "'"

    private fun postProgress(callback: (String) -> Unit, value: String) {
        mainHandler.post { callback(value) }
    }

    private fun postDone(callback: (Boolean, String) -> Unit, success: Boolean, value: String) {
        mainHandler.post { callback(success, value) }
    }
}
