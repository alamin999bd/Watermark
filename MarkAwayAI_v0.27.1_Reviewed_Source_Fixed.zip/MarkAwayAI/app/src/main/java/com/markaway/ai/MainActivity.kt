package com.markaway.ai

import android.content.ContentValues
import android.content.Intent
import android.content.ContentUris
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import android.content.Context
import android.text.SpannableString
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.TextOverlay
import androidx.media3.effect.StaticOverlaySettings
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import com.google.common.collect.ImmutableList
import java.io.File
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.InputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Ink = Color(0xFF090B14)
private val Panel = Color(0xFF151A2B)
private val Violet = Color(0xFF8B5CF6)
private val Cyan = Color(0xFF22D3EE)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MarkAwayApp() }
    }
}

@Composable
fun MarkAwayApp() {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var page by remember { mutableStateOf("home") }
    val preferences = remember { context.getSharedPreferences("markaway_settings", Context.MODE_PRIVATE) }
    var accentChoice by remember { mutableStateOf(preferences.getString("accent", "Violet") ?: "Violet") }
    var reduceMotion by remember { mutableStateOf(preferences.getBoolean("reduce_motion", false)) }
    val activePrimary = when (accentChoice) { "Blue" -> Color(0xFF3B82F6); "Emerald" -> Color(0xFF10B981); else -> Violet }
    var galleryItems by remember { mutableStateOf<List<SavedMedia>>(emptyList()) }
    var sourceUri by remember { mutableStateOf<Uri?>(null) }
    var bitmap by remember { mutableStateOf<Bitmap?>(null) }
    var watermarkText by remember { mutableStateOf("© My Brand") }
    var textMarkScale by remember { mutableFloatStateOf(0.055f) }
    var textMarkOpacity by remember { mutableFloatStateOf(0.75f) }
    var logoBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var logoOpacity by remember { mutableFloatStateOf(0.85f) }
    var logoX by remember { mutableFloatStateOf(0.82f) }
    var logoY by remember { mutableFloatStateOf(0.82f) }
    var logoScale by remember { mutableFloatStateOf(1f) }
    var logoRotation by remember { mutableFloatStateOf(0f) }
    var brushRadius by remember { mutableFloatStateOf(0.035f) }
    var maskStrokes by remember { mutableStateOf<List<List<Offset>>>(emptyList()) }
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var videoStatus by remember { mutableStateOf("Choose a video and position the cover over its watermark") }
    var exporting by remember { mutableStateOf(false) }
    var videoMaskX by remember { mutableFloatStateOf(0.78f) }
    var videoMaskY by remember { mutableFloatStateOf(0.88f) }
    var videoMaskWidth by remember { mutableFloatStateOf(0.24f) }
    var status by remember { mutableStateOf("Choose an image to begin") }
    val logoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            logoBitmap = null
            try {
                context.contentResolver.openInputStream(uri).use { logoBitmap = BitmapFactory.decodeStream(it) }
                if (logoBitmap == null) status = "Could not read this logo image"
            } catch (_: Exception) { status = "Could not open logo image" }
        }
    }
    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) { videoUri = uri; videoStatus = "Video selected. Add text and export." }
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            sourceUri = uri
            bitmap = null
            try {
                context.contentResolver.openInputStream(uri).use { stream ->
                    bitmap = BitmapFactory.decodeStream(stream)
                }
                status = if (bitmap != null) "Image loaded successfully" else "Could not read this image"
            } catch (_: Exception) { status = "Could not open image" }
        }
    }

    BackHandler(enabled = page != "home") { page = "home" }

    MaterialTheme(colorScheme = darkColorScheme(primary = activePrimary, secondary = Cyan, background = Ink, surface = Panel)) {
        Surface(modifier = Modifier.fillMaxSize(), color = Ink) {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(42.dp).background(Brush.linearGradient(listOf(Violet, Cyan)), CircleShape), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.AutoFixHigh, null, tint = Color.White)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("MarkAway", fontSize = 25.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
                        Text("AI WATERMARK STUDIO", fontSize = 10.sp, color = Cyan, letterSpacing = 2.sp)
                    }
                }
                Spacer(Modifier.height(28.dp))
                AnimatedContent(targetState = page, transitionSpec = {
                    if (reduceMotion) {
                        fadeIn(animationSpec = tween(80)) togetherWith fadeOut(animationSpec = tween(80))
                    } else {
                        (fadeIn() + slideInHorizontally { it / 8 }) togetherWith (fadeOut() + slideOutHorizontally { -it / 8 })
                    }
                }, label = "page") { current ->
                    when (current) {
                        "add" -> EditorPanel(title = "Add watermark", description = "Add your own text mark to an image.", bitmap = bitmap, status = status,
                            watermarkText = watermarkText, onText = { watermarkText = it },
                            textScale = textMarkScale, onTextScale = { textMarkScale = it },
                            textOpacity = textMarkOpacity, onTextOpacity = { textMarkOpacity = it },
                            onPick = { picker.launch(arrayOf("image/*")) },
                            onSave = {
                                val original = bitmap
                                if (original == null) status = "Choose an image first" else if (watermarkText.isBlank()) status = "Enter watermark text" else {
                                    val output = addTextWatermark(original, watermarkText, textMarkScale, textMarkOpacity)
                                    val saved = saveBitmap(context, output)
                                    status = if (saved) "Saved to Pictures/MarkAway" else "Save failed"
                                }
                            }, actionLabel = "Apply & save")
                        "logo" -> LogoPanel(
                            bitmap = bitmap, logo = logoBitmap, opacity = logoOpacity,
                            logoX = logoX, logoY = logoY, logoScale = logoScale, logoRotation = logoRotation,
                            onPosition = { x, y -> logoX = x; logoY = y }, onScale = { logoScale = it }, onRotation = { logoRotation = it },
                            onOpacity = { logoOpacity = it }, status = status,
                            onPickImage = { picker.launch(arrayOf("image/*")) },
                            onPickLogo = { logoPicker.launch(arrayOf("image/*")) },
                            onSave = {
                                val original = bitmap
                                val mark = logoBitmap
                                if (original == null) status = "Choose a base image first"
                                else if (mark == null) status = "Choose a logo image first"
                                else {
                                    val output = addLogoWatermark(original, mark, logoOpacity, logoX, logoY, logoScale, logoRotation)
                                    status = if (saveBitmap(context, output)) "Logo watermark saved to Pictures/MarkAway" else "Save failed"
                                }
                            }
                        )
                        "video" -> VideoPanel(
                            videoUri = videoUri,
                            maskX = videoMaskX, onMaskX = { videoMaskX = it },
                            maskY = videoMaskY, onMaskY = { videoMaskY = it },
                            maskWidth = videoMaskWidth, onMaskWidth = { videoMaskWidth = it },
                            status = videoStatus, exporting = exporting,
                            onPick = { videoPicker.launch(arrayOf("video/*")) },
                            onExport = {
                                val input = videoUri
                                if (input == null) videoStatus = "Choose a video first"
                                else if (!exporting) {
                                    exporting = true
                                    videoStatus = "Preparing frame-by-frame AI removal…"
                                    VideoAiRemovalEngine.start(context, input, videoMaskX, videoMaskY, videoMaskWidth,
                                        onProgress = { videoStatus = it },
                                        onDone = { _, message -> exporting = false; videoStatus = message })
                                }
                            }
                        )
                        "settings" -> SettingsPanel(
                            accentChoice = accentChoice, onAccentChange = { choice -> accentChoice = choice; preferences.edit().putString("accent", choice).apply() },
                            reduceMotion = reduceMotion, onReduceMotionChange = { enabled -> reduceMotion = enabled; preferences.edit().putBoolean("reduce_motion", enabled).apply() }
                        )
                        "gallery" -> GalleryPanel(
                            items = galleryItems,
                            onRefresh = { galleryItems = loadSavedMedia(context) },
                            onOpen = { item -> openSavedMedia(context, item) },
                            onShare = { item -> shareSavedMedia(context, item) },
                            onDelete = { item ->
                                val deleted = try { context.contentResolver.delete(item.uri, null, null) > 0 } catch (_: Exception) { false }
                                galleryItems = loadSavedMedia(context)
                                Toast.makeText(context, if (deleted) "Media deleted" else "Could not delete media", Toast.LENGTH_SHORT).show()
                            }
                        )
                        "remove" -> MaskRemovalPanel(
                            bitmap = bitmap, strokes = maskStrokes,
                            onStrokesChange = { maskStrokes = it },
                            brushRadius = brushRadius,
                            onBrushRadiusChange = { brushRadius = it },
                            status = status,
                            onPick = { picker.launch(arrayOf("image/*")) },
                            onRepair = {
                                val original = bitmap
                                if (original == null) status = "Choose an image first"
                                else if (maskStrokes.isEmpty()) status = "Paint over the area you want to repair"
                                else if (!LiteRtMiganInpaintingEngine.isModelBundled(context)) {
                                    status = "AI model is missing. Build using the GitHub Actions workflow."
                                } else {
                                    val strokes = maskStrokes
                                    val radius = brushRadius
                                    status = "AI repair running on this device…"
                                    coroutineScope.launch {
                                        try {
                                            val saved = withContext(Dispatchers.IO) {
                                                val mask = createMaskBitmap(original.width, original.height, strokes, radius)
                                                try {
                                                    val output = LiteRtMiganInpaintingEngine.repair(context, original, mask)
                                                    try { saveBitmap(context, output) }
                                                    finally { if (!output.isRecycled) output.recycle() }
                                                } finally {
                                                    if (!mask.isRecycled) mask.recycle()
                                                }
                                            }
                                            status = if (saved) "AI repair saved to Pictures/MarkAway" else "Save failed"
                                            if (saved) maskStrokes = emptyList()
                                        } catch (error: Exception) {
                                            status = "AI repair failed: ${error.message ?: "unknown error"}"
                                        }
                                    }
                                }
                            }
                        )
                        else -> HomePanel(reduceMotion = reduceMotion, onAdd = { page = "add" }, onRemove = { page = "remove" }, onVideo = { page = "video" }, onLogo = { page = "logo" }, onGallery = { galleryItems = loadSavedMedia(context); page = "gallery" }, onSettings = { page = "settings" })
                    }
                }
                Spacer(Modifier.height(22.dp))
                Text("OFFLINE • NO API • NO ACCOUNT", color = Color(0xFF8D96B2), fontSize = 11.sp, letterSpacing = 1.5.sp)
                Spacer(Modifier.height(8.dp))
                Text("Media stays on your device. Image and video AI inpainting require the MI-GAN model asset. Video AI processes a fixed selected area frame by frame; moving-watermark tracking is not included.", color = Color(0xFF9AA3BA), fontSize = 12.sp, lineHeight = 18.sp)
            }
        }
    }
}


@Composable
private fun SettingsPanel(
    accentChoice: String, onAccentChange: (String) -> Unit,
    reduceMotion: Boolean, onReduceMotionChange: (Boolean) -> Unit
) {
    Column {
        Text("Settings", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Text("Personalize the MarkAway workspace.", color = Color(0xFFAAB2C8), fontSize = 13.sp)
        Spacer(Modifier.height(18.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Accent color", color = Color.White, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(6.dp))
                Text("Choose the primary highlight used by Material controls.", color = Color(0xFFAAB2C8), fontSize = 12.sp)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Violet", "Blue", "Emerald").forEach { option ->
                        FilterChip(selected = accentChoice == option, onClick = { onAccentChange(option) }, label = { Text(option) })
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Reduce motion", color = Color.White, fontWeight = FontWeight.SemiBold)
                    Text("Reduce page and home-card animations. Saved on this device.", color = Color(0xFFAAB2C8), fontSize = 12.sp)
                }
                Switch(checked = reduceMotion, onCheckedChange = onReduceMotionChange)
            }
        }
        Spacer(Modifier.height(12.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("About MarkAway", color = Color.White, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(6.dp))
                Text("Version ${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})", color = Cyan, fontSize = 13.sp)
                Text("Offline workspace. Exported media is stored in Pictures/MarkAway and Movies/MarkAway.", color = Color(0xFFAAB2C8), fontSize = 12.sp, lineHeight = 18.sp)
                Spacer(Modifier.height(6.dp))
                Text("AI image and video inpainting require the MI-GAN model asset. Video AI supports a fixed selected area only; moving-watermark tracking is not included.", color = Color(0xFFFFC66D), fontSize = 12.sp, lineHeight = 18.sp)
            }
        }
    }
}

@Composable
private fun HomePanel(reduceMotion: Boolean, onAdd: () -> Unit, onRemove: () -> Unit, onVideo: () -> Unit, onLogo: () -> Unit, onGallery: () -> Unit, onSettings: () -> Unit) {
    Column {
        Text("Create without limits.", color = Color.White, fontSize = 29.sp, fontWeight = FontWeight.Bold, lineHeight = 35.sp)
        Spacer(Modifier.height(8.dp))
        Text("Your private, offline watermark workspace.", color = Color(0xFFAAB2C8), fontSize = 14.sp)
        Spacer(Modifier.height(24.dp))
        FeatureCard("Remove watermark", "Work on an image", Icons.Default.AutoFixHigh, reduceMotion, onRemove)
        Spacer(Modifier.height(12.dp))
        FeatureCard("Add watermark", "Brand images with text", Icons.Default.TextFields, reduceMotion, onAdd)
        Spacer(Modifier.height(12.dp))
        FeatureCard("Add logo", "Place your own logo on an image", Icons.Default.Image, reduceMotion, onLogo)
        Spacer(Modifier.height(12.dp))
        FeatureCard("Video watermark removal", "Cover a selected watermark area", Icons.Default.Movie, reduceMotion, onVideo)
        Spacer(Modifier.height(12.dp))
        FeatureCard("My Gallery", "View images and videos saved by MarkAway", Icons.Default.Image, reduceMotion, onGallery)
        Spacer(Modifier.height(12.dp))
        FeatureCard("Settings", "Appearance and app preferences", Icons.Default.Settings, reduceMotion, onSettings)
        Spacer(Modifier.height(20.dp))
        Text("Designed for a clean, premium workflow", color = Color.White, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun FeatureCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, reduceMotion: Boolean, onClick: () -> Unit) {
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(reduceMotion) { visible = true }
    val infinite = rememberInfiniteTransition(label = "feature-icon-pulse")
    val animatedIconRotation by infinite.animateFloat(
        initialValue = -2f,
        targetValue = 2f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "icon-rotation"
    )
    val iconRotation = if (reduceMotion) 0f else animatedIconRotation
    AnimatedVisibility(
        visible = visible,
        enter = if (reduceMotion) fadeIn(tween(80)) else fadeIn(tween(420)) + slideInVertically(
            animationSpec = tween(420, easing = FastOutSlowInEasing),
            initialOffsetY = { it / 5 }
        ) + expandVertically(tween(420))
    ) {
        Card(
            onClick = onClick,
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(containerColor = Panel),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(48.dp).background(
                        Brush.linearGradient(listOf(Violet, Cyan)), RoundedCornerShape(15.dp)
                    ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, null, tint = Color.White, modifier = Modifier.graphicsLayer { rotationZ = iconRotation })
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text(subtitle, color = Color(0xFF9AA3BA), fontSize = 12.sp)
                }
                Text("›", color = Cyan, fontSize = 28.sp)
            }
        }
    }
}

private data class SavedMedia(val uri: Uri, val name: String, val mimeType: String, val dateAdded: Long)

private fun loadSavedMedia(context: Context): List<SavedMedia> {
    val result = mutableListOf<SavedMedia>()
    val collections = listOf(
        MediaStore.Images.Media.EXTERNAL_CONTENT_URI to "Pictures/MarkAway/%",
        MediaStore.Video.Media.EXTERNAL_CONTENT_URI to "Movies/MarkAway/%"
    )
    for ((collection, pathPattern) in collections) {
        val projection = arrayOf(
            MediaStore.MediaColumns._ID,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.MIME_TYPE,
            MediaStore.MediaColumns.DATE_ADDED
        )
        try {
            context.contentResolver.query(
                collection, projection,
                "${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?", arrayOf(pathPattern),
                "${MediaStore.MediaColumns.DATE_ADDED} DESC"
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.MIME_TYPE)
                val dateCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_ADDED)
                // Bound each media query so a very large device library cannot create
                // an unbounded Compose list or long UI-thread cursor traversal.
                var loadedCount = 0
                while (cursor.moveToNext() && loadedCount < 200) {
                    val id = cursor.getLong(idCol)
                    result += SavedMedia(
                        ContentUris.withAppendedId(collection, id),
                        cursor.getString(nameCol) ?: "MarkAway media",
                        cursor.getString(mimeCol) ?: "application/octet-stream",
                        cursor.getLong(dateCol)
                    )
                    loadedCount++
                }
            }
        } catch (_: Exception) { /* Keep the gallery usable if a media provider rejects a query. */ }
    }
    return result.sortedByDescending { it.dateAdded }
}

private fun openSavedMedia(context: Context, item: SavedMedia) {
    try {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(item.uri, item.mimeType)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(intent)
    } catch (_: Exception) {
        Toast.makeText(context, "No app found to open this file", Toast.LENGTH_SHORT).show()
    }
}

private fun shareSavedMedia(context: Context, item: SavedMedia) {
    try {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = item.mimeType
            putExtra(Intent.EXTRA_STREAM, item.uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Share with"))
    } catch (_: Exception) {
        Toast.makeText(context, "Could not share this file", Toast.LENGTH_SHORT).show()
    }
}

@Composable
private fun GalleryPanel(
    items: List<SavedMedia>, onRefresh: () -> Unit,
    onOpen: (SavedMedia) -> Unit, onShare: (SavedMedia) -> Unit,
    onDelete: (SavedMedia) -> Unit
) {
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("All") }
    val visibleItems = items.filter { item ->
        val matchesQuery = item.name.contains(query.trim(), ignoreCase = true)
        val matchesType = when (filter) {
            "Images" -> item.mimeType.startsWith("image/")
            "Videos" -> item.mimeType.startsWith("video/")
            else -> true
        }
        matchesQuery && matchesType
    }
    Column {
        Text("My Gallery", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Text("Your exported MarkAway photos and videos, stored on this device.", color = Color(0xFFAAB2C8), fontSize = 13.sp)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = query, onValueChange = { query = it },
            label = { Text("Search saved files") }, singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("All", "Images", "Videos").forEach { option ->
                FilterChip(
                    selected = filter == option,
                    onClick = { filter = option },
                    label = { Text(option) }
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        Button(onClick = onRefresh, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Panel)) {
            Icon(Icons.Default.Image, null); Spacer(Modifier.width(8.dp)); Text("Refresh gallery")
        }
        if (visibleItems.isEmpty()) {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.AddPhotoAlternate, null, tint = Cyan, modifier = Modifier.size(36.dp))
                    Spacer(Modifier.height(8.dp))
                    Text(if (items.isEmpty()) "No MarkAway exports yet" else "No matching files", color = Color.White, fontWeight = FontWeight.SemiBold)
                    Text(if (items.isEmpty()) "Saved images and videos will appear here." else "Try another search or filter.", color = Color(0xFFAAB2C8), fontSize = 12.sp)
                }
            }
        } else {
            Text("${visibleItems.size} file(s)", color = Color(0xFFAAB2C8), fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp))
            visibleItems.forEach { item ->
                Card(onClick = { onOpen(item) }, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(if (item.mimeType.startsWith("video/")) Icons.Default.Movie else Icons.Default.Image, null, tint = Cyan, modifier = Modifier.size(28.dp))
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(item.name, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1)
                            Text(if (item.mimeType.startsWith("video/")) "VIDEO" else "IMAGE", color = Color(0xFFAAB2C8), fontSize = 10.sp, letterSpacing = 1.sp)
                        }
                        IconButton(onClick = { onShare(item) }) {
                            Icon(Icons.Default.Share, contentDescription = "Share media", tint = Cyan)
                        }
                        IconButton(onClick = { onDelete(item) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete media", tint = Color(0xFFFF7B86))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EditorPanel(title: String, description: String, bitmap: Bitmap?, status: String, watermarkText: String, onText: (String) -> Unit, textScale: Float, onTextScale: (Float) -> Unit, textOpacity: Float, onTextOpacity: (Float) -> Unit, onPick: () -> Unit, onSave: () -> Unit, actionLabel: String) {
    Column {
        Text(title, color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Text(description, color = Color(0xFFAAB2C8), fontSize = 13.sp, lineHeight = 19.sp)
        Spacer(Modifier.height(18.dp))
        Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth().height(230.dp)) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                if (bitmap != null) {
                    Image(bitmap.asImageBitmap(), null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                    if (watermarkText.isNotBlank()) {
                        Text(
                            text = watermarkText,
                            color = Color.White.copy(alpha = textOpacity.coerceIn(0.15f, 1f)),
                            fontSize = (textScale * 2300f).coerceIn(12f, 34f).sp,
                            fontWeight = FontWeight.SemiBold,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 16.dp)
                        )
                    }
                } else Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.AddPhotoAlternate, null, tint = Cyan, modifier = Modifier.size(42.dp))
                    Text("No image selected", color = Color(0xFFAAB2C8))
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        Button(onClick = onPick, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Panel)) { Icon(Icons.Default.Image, null); Spacer(Modifier.width(8.dp)); Text("Choose image") }
        OutlinedTextField(value = watermarkText, onValueChange = onText, label = { Text("Watermark text") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Spacer(Modifier.height(8.dp))
        Text("Text size: ${(textScale * 100).toInt()}%", color = Color.White, fontSize = 13.sp)
        Slider(value = textScale, onValueChange = onTextScale, valueRange = 0.03f..0.10f)
        Text("Opacity: ${(textOpacity * 100).toInt()}%", color = Color.White, fontSize = 13.sp)
        Slider(value = textOpacity, onValueChange = onTextOpacity, valueRange = 0.15f..1f)
        Spacer(Modifier.height(12.dp))
        Button(onClick = onSave, enabled = bitmap != null && watermarkText.isNotBlank(), modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Violet)) { Icon(Icons.Default.Save, null); Spacer(Modifier.width(8.dp)); Text(actionLabel) }
        Text(status, color = Cyan, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
    }
}



@Composable
private fun LogoPanel(
    bitmap: Bitmap?, logo: Bitmap?, opacity: Float,
    logoX: Float, logoY: Float, logoScale: Float, logoRotation: Float,
    onPosition: (Float, Float) -> Unit, onScale: (Float) -> Unit, onRotation: (Float) -> Unit,
    onOpacity: (Float) -> Unit,
    status: String, onPickImage: () -> Unit, onPickLogo: () -> Unit, onSave: () -> Unit
) {
    Column {
        Text("Add logo watermark", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Text("Drag the logo to move it. Pinch with two fingers or use the size slider to resize it.", color = Color(0xFFAAB2C8), fontSize = 13.sp, lineHeight = 19.sp)
        Spacer(Modifier.height(14.dp))
        BoxWithConstraints(
            Modifier.fillMaxWidth().height(260.dp)
                .background(Panel, RoundedCornerShape(20.dp))
                .pointerInput(bitmap, logo) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        if (bitmap != null && logo != null) {
                            onPosition(
                                (logoX + pan.x / size.width).coerceIn(0.03f, 0.97f),
                                (logoY + pan.y / size.height).coerceIn(0.03f, 0.97f)
                            )
                            onScale((logoScale * zoom).coerceIn(0.25f, 3f))
                        }
                    }
                }
        ) {
            if (bitmap != null) {
                Image(bitmap.asImageBitmap(), null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                if (logo != null) {
                    val logoWidth = maxWidth * (0.18f * logoScale)
                    val ratio = logo.height.toFloat() / logo.width.toFloat().coerceAtLeast(1f)
                    val logoHeight = logoWidth * ratio
                    Image(
                        bitmap = logo.asImageBitmap(),
                        contentDescription = "Movable logo preview",
                        modifier = Modifier
                            .width(logoWidth)
                            .height(logoHeight)
                            .graphicsLayer { rotationZ = logoRotation }
                            .offset(
                                x = maxWidth * logoX - logoWidth / 2,
                                y = maxHeight * logoY - logoHeight / 2
                            ),
                        alpha = opacity,
                        contentScale = ContentScale.Fit
                    )
                }
            } else {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Choose a photo to begin", color = Color(0xFFAAB2C8))
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Button(onClick = onPickImage, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Panel)) {
            Icon(Icons.Default.Image, null); Spacer(Modifier.width(8.dp)); Text("Choose base image")
        }
        Button(onClick = onPickLogo, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Panel)) {
            Icon(Icons.Default.AddPhotoAlternate, null); Spacer(Modifier.width(8.dp)); Text(if (logo == null) "Choose logo image" else "Change logo image")
        }
        Text("Logo size: ${(logoScale * 100).toInt()}%", color = Color.White, fontSize = 13.sp)
        Slider(value = logoScale, onValueChange = onScale, valueRange = 0.25f..3f)
        Text("Logo opacity: ${(opacity * 100).toInt()}%", color = Color.White, fontSize = 13.sp)
        Slider(value = opacity, onValueChange = onOpacity, valueRange = 0.15f..1f)
        Text("Logo rotation: ${logoRotation.toInt()}°", color = Color.White, fontSize = 13.sp)
        Slider(value = logoRotation, onValueChange = onRotation, valueRange = -180f..180f)
        Button(onClick = { onPosition(0.82f, 0.82f); onScale(1f); onRotation(0f) }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Panel)) {
            Text("Reset logo position and size")
        }
        Button(onClick = onSave, enabled = bitmap != null && logo != null, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Violet)) {
            Icon(Icons.Default.Save, null); Spacer(Modifier.width(8.dp)); Text("Apply logo & save")
        }
        Text(status, color = Cyan, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
    }
}

private fun addLogoWatermark(source: Bitmap, logo: Bitmap, opacity: Float, centerX: Float, centerY: Float, scale: Float, rotation: Float): Bitmap {
    val result = source.copy(Bitmap.Config.ARGB_8888, true)
    val canvas = Canvas(result)
    val targetWidth = (source.width * 0.18f * scale).coerceIn(1f, source.width.toFloat()).toInt()
    val ratio = logo.height.toFloat() / logo.width.toFloat().coerceAtLeast(1f)
    val targetHeight = (targetWidth * ratio).coerceAtLeast(1f).toInt()
    val cx = (centerX.coerceIn(0f, 1f) * source.width).toInt()
    val cy = (centerY.coerceIn(0f, 1f) * source.height).toInt()
    val left = (cx - targetWidth / 2).coerceIn(0, (source.width - targetWidth).coerceAtLeast(0))
    val top = (cy - targetHeight / 2).coerceIn(0, (source.height - targetHeight).coerceAtLeast(0))
    val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
        alpha = (opacity.coerceIn(0f, 1f) * 255).toInt()
    }
    canvas.save()
    canvas.rotate(rotation, cx.toFloat(), cy.toFloat())
    canvas.drawBitmap(logo, null, Rect(left, top, left + targetWidth, top + targetHeight), paint)
    canvas.restore()
    return result
}

@Composable
private fun MaskRemovalPanel(
    bitmap: Bitmap?, strokes: List<List<Offset>>,
    onStrokesChange: (List<List<Offset>>) -> Unit,
    brushRadius: Float, onBrushRadiusChange: (Float) -> Unit,
    status: String, onPick: () -> Unit, onRepair: () -> Unit
) {
    val sourceBitmap = bitmap
    val latestStrokes by rememberUpdatedState(strokes)
    val latestOnStrokesChange by rememberUpdatedState(onStrokesChange)
    Column {
        Text("Remove watermark", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Text("Choose an image, paint over the area to remove, then run offline AI inpainting. Processing uses a centered 512×512 crop.", color = Color(0xFFAAB2C8), fontSize = 13.sp, lineHeight = 19.sp)
        Spacer(Modifier.height(14.dp))
        Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth().height(300.dp)) {
            if (sourceBitmap == null) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Choose an image to begin", color = Color(0xFFAAB2C8))
            } else Canvas(
                Modifier.fillMaxSize().pointerInput(sourceBitmap) {
                    val imageScale = minOf(size.width / sourceBitmap.width.toFloat(), size.height / sourceBitmap.height.toFloat())
                    val drawnWidth = sourceBitmap.width * imageScale
                    val drawnHeight = sourceBitmap.height * imageScale
                    val offsetX = (size.width - drawnWidth) / 2f
                    val offsetY = (size.height - drawnHeight) / 2f
                    fun isInsideImage(position: Offset) =
                        position.x >= offsetX && position.x <= offsetX + drawnWidth &&
                        position.y >= offsetY && position.y <= offsetY + drawnHeight
                    fun imagePoint(position: Offset) = Offset(
                        ((position.x - offsetX) / drawnWidth).coerceIn(0f, 1f),
                        ((position.y - offsetY) / drawnHeight).coerceIn(0f, 1f)
                    )
                    var drawingOnImage = false
                    detectDragGestures(
                        onDragStart = { start ->
                            drawingOnImage = isInsideImage(start)
                            if (drawingOnImage) {
                                latestOnStrokesChange(latestStrokes + listOf(listOf(imagePoint(start))))
                            }
                        },
                        onDrag = { change, _ ->
                            change.consume()
                            if (drawingOnImage) {
                                val p = imagePoint(change.position)
                                val updated = latestStrokes.toMutableList()
                                if (updated.isNotEmpty()) updated[updated.lastIndex] = updated.last() + p
                                latestOnStrokesChange(updated)
                            }
                        },
                        onDragEnd = { drawingOnImage = false },
                        onDragCancel = { drawingOnImage = false }
                    )
                }
            ) {
                val imageScale = minOf(size.width / sourceBitmap.width.toFloat(), size.height / sourceBitmap.height.toFloat())
                val drawnWidth = sourceBitmap.width * imageScale
                val drawnHeight = sourceBitmap.height * imageScale
                val offsetX = (size.width - drawnWidth) / 2f
                val offsetY = (size.height - drawnHeight) / 2f
                val imageSize = androidx.compose.ui.unit.IntSize(drawnWidth.toInt(), drawnHeight.toInt())
                drawImage(sourceBitmap.asImageBitmap(), dstOffset = IntOffset(offsetX.toInt(), offsetY.toInt()), dstSize = imageSize)
                strokes.forEach { points ->
                    if (points.size == 1) {
                        drawCircle(Color(0xAA22D3EE), minOf(drawnWidth, drawnHeight) * brushRadius,
                            Offset(offsetX + points[0].x * drawnWidth, offsetY + points[0].y * drawnHeight))
                    } else if (points.size > 1) {
                        val path = Path().apply {
                            moveTo(offsetX + points.first().x * drawnWidth, offsetY + points.first().y * drawnHeight)
                            points.drop(1).forEach { lineTo(offsetX + it.x * drawnWidth, offsetY + it.y * drawnHeight) }
                        }
                        drawPath(path, Color(0xAA22D3EE), style = Stroke(width = minOf(drawnWidth, drawnHeight) * brushRadius * 2f))
                    }
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        Button(onClick = onPick, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Panel)) {
            Icon(Icons.Default.Image, null); Spacer(Modifier.width(8.dp)); Text("Choose image")
        }
        Text("Brush size", color = Color.White, fontSize = 13.sp)
        Slider(value = brushRadius, onValueChange = onBrushRadiusChange, valueRange = 0.008f..0.09f)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(
                onClick = { if (strokes.isNotEmpty()) onStrokesChange(strokes.dropLast(1)) },
                enabled = strokes.isNotEmpty(), modifier = Modifier.weight(1f)
            ) { Text("Undo") }
            OutlinedButton(
                onClick = { onStrokesChange(emptyList()) },
                enabled = strokes.isNotEmpty(), modifier = Modifier.weight(1f)
            ) { Text("Clear") }
        }
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = onRepair, enabled = bitmap != null && strokes.isNotEmpty(),
            modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Violet)
        ) {
            Icon(Icons.Default.AutoFixHigh, null); Spacer(Modifier.width(6.dp)); Text("Repair & save")
        }
        Text(status, color = Cyan, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
    }
}

private fun createMaskBitmap(width: Int, height: Int, strokes: List<List<Offset>>, brushRadius: Float): Bitmap {
    val mask = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(mask)
    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.WHITE
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        strokeWidth = (minOf(width, height) * brushRadius * 2f).coerceAtLeast(2f)
    }
    strokes.forEach { stroke ->
        if (stroke.isEmpty()) return@forEach
        if (stroke.size == 1) {
            paint.style = Paint.Style.FILL
            canvas.drawCircle(stroke[0].x * width, stroke[0].y * height, paint.strokeWidth / 2f, paint)
            paint.style = Paint.Style.STROKE
        } else {
            val path = android.graphics.Path().apply {
                moveTo(stroke.first().x * width, stroke.first().y * height)
                stroke.drop(1).forEach { lineTo(it.x * width, it.y * height) }
            }
            canvas.drawPath(path, paint)
        }
    }
    return mask
}

private fun addTextWatermark(source: Bitmap, text: String, scale: Float, opacity: Float): Bitmap {
    val result = source.copy(Bitmap.Config.ARGB_8888, true)
    val canvas = Canvas(result)
    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.WHITE
        textSize = (source.width * scale.coerceIn(0.03f, 0.10f)).coerceIn(18f, 160f)
        alpha = (opacity.coerceIn(0.15f, 1f) * 255).toInt()
        textAlign = Paint.Align.CENTER
        setShadowLayer(4f, 2f, 2f, android.graphics.Color.BLACK)
    }
    canvas.drawText(text.ifBlank { "© My Brand" }, source.width * 0.5f, source.height * 0.94f, paint)
    return result
}

private fun fillCenterPatch(source: Bitmap): Bitmap {
    // Basic non-AI patch fill: interpolate colors from the left/right borders
    // and blend with the top/bottom borders. This is intentionally labelled
    // as a basic tool; it is not a neural inpainting model.
    val result = source.copy(Bitmap.Config.ARGB_8888, true)
    val w = source.width
    val h = source.height
    val left = (w * 0.35f).toInt().coerceIn(1, w - 2)
    val right = (w * 0.65f).toInt().coerceIn(left + 1, w - 1)
    val top = (h * 0.35f).toInt().coerceIn(1, h - 2)
    val bottom = (h * 0.55f).toInt().coerceIn(top + 1, h - 1)
    val pixels = IntArray(w * h)
    source.getPixels(pixels, 0, w, 0, 0, w, h)
    fun channel(c: Int, shift: Int) = (c shr shift) and 0xff
    for (y in top until bottom) {
        val fy = (y - top).toFloat() / (bottom - top).coerceAtLeast(1)
        for (x in left until right) {
            val fx = (x - left).toFloat() / (right - left).coerceAtLeast(1)
            val a = pixels[y * w + left - 1]
            val b = pixels[y * w + right]
            val c = pixels[(top - 1) * w + x]
            val d = pixels[bottom * w + x]
            val out = IntArray(4)
            for (shiftIndex in 0..3) {
                val shift = 24 - shiftIndex * 8
                val horizontal = channel(a, shift) * (1f - fx) + channel(b, shift) * fx
                val vertical = channel(c, shift) * (1f - fy) + channel(d, shift) * fy
                out[shiftIndex] = ((horizontal + vertical) / 2f).toInt().coerceIn(0, 255)
            }
            pixels[y * w + x] = (out[0] shl 24) or (out[1] shl 16) or (out[2] shl 8) or out[3]
        }
    }
    result.setPixels(pixels, 0, w, 0, 0, w, h)
    return result
}

private fun saveBitmap(context: android.content.Context, bitmap: Bitmap): Boolean {
    var insertedUri: Uri? = null
    return try {
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "MarkAway_${System.currentTimeMillis()}.png")
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/MarkAway")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        insertedUri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            ?: return false
        val output = context.contentResolver.openOutputStream(insertedUri!!)
            ?: throw IllegalStateException("Could not open image output stream")
        val compressed = output.use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
        if (!compressed) throw IllegalStateException("Image encoding failed")
        val publish = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
        val published = context.contentResolver.update(insertedUri!!, publish, null, null)
        if (published <= 0) throw IllegalStateException("Could not publish saved image")
        true
    } catch (_: Exception) {
        insertedUri?.let { runCatching { context.contentResolver.delete(it, null, null) } }
        false
    }
}


@Composable
private fun VideoPanel(
    videoUri: Uri?, maskX: Float, onMaskX: (Float) -> Unit,
    maskY: Float, onMaskY: (Float) -> Unit,
    maskWidth: Float, onMaskWidth: (Float) -> Unit,
    status: String, exporting: Boolean, onPick: () -> Unit, onExport: () -> Unit
) {
    Column {
        Text("Video Watermark Removal", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Text("Select a short video, position the removal area, then run offline frame-by-frame AI inpainting.", color = Color(0xFFAAB2C8), fontSize = 13.sp)
        Spacer(Modifier.height(18.dp))
        Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth().height(132.dp)) {
            Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Icon(Icons.Default.Movie, null, tint = Cyan, modifier = Modifier.size(42.dp))
                Text(if (videoUri == null) "No video selected" else "Video ready — adjust cover position below", color = Color.White)
            }
        }
        Spacer(Modifier.height(14.dp))
        Button(onClick = onPick, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Panel)) {
            Icon(Icons.Default.Movie, null); Spacer(Modifier.width(8.dp)); Text("Choose video")
        }
        Spacer(Modifier.height(12.dp))
        Text("Cover position — horizontal", color = Color.White, fontWeight = FontWeight.SemiBold)
        Slider(value = maskX, onValueChange = onMaskX, valueRange = 0.08f..0.92f)
        Text("Cover position — vertical", color = Color.White, fontWeight = FontWeight.SemiBold)
        Slider(value = maskY, onValueChange = onMaskY, valueRange = 0.08f..0.92f)
        Text("Cover size", color = Color.White, fontWeight = FontWeight.SemiBold)
        Slider(value = maskWidth, onValueChange = onMaskWidth, valueRange = 0.10f..0.42f)
        Text("AI mode: reconstructs the selected fixed area in every frame. Current limit: 20 seconds per clip. Moving-watermark tracking is not included yet.", color = Color(0xFFFFC66D), fontSize = 12.sp, lineHeight = 17.sp)
        Spacer(Modifier.height(12.dp))
        Button(onClick = onExport, enabled = !exporting && videoUri != null, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Violet)) {
            if (exporting) CircularProgressIndicator(Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
            else Icon(Icons.Default.AutoFixHigh, null)
            Spacer(Modifier.width(8.dp)); Text(if (exporting) "AI processing…" else "AI Remove Watermark & Export")
        }
        Text(status, color = Cyan, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
    }
}

@OptIn(UnstableApi::class)
private fun exportVideoWithMask(
    context: Context, inputUri: Uri, centerX: Float, centerY: Float, widthFraction: Float,
    onProgress: (String) -> Unit, onDone: (Boolean, String) -> Unit
) {
    var outputFile: File? = null
    try {
        val out = File(context.cacheDir, "markaway_video_${System.currentTimeMillis()}.mp4")
        outputFile = out
        // A neutral mosaic patch obscures the selected watermark region. This is masking,
        // not AI inpainting or reconstruction of the pixels behind the watermark.
        val patch = Bitmap.createBitmap(320, 128, Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(patch)
        val cell = 16
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        for (y in 0 until 128 step cell) {
            for (x in 0 until 320 step cell) {
                val light = ((x / cell) + (y / cell)) % 2 == 0
                paint.color = if (light) android.graphics.Color.argb(238, 82, 91, 111)
                              else android.graphics.Color.argb(238, 48, 56, 74)
                canvas.drawRect(x.toFloat(), y.toFloat(), (x + cell).toFloat(), (y + cell).toFloat(), paint)
            }
        }
        val anchorX = (centerX.coerceIn(0.05f, 0.95f) * 2f) - 1f
        val anchorY = 1f - (centerY.coerceIn(0.05f, 0.95f) * 2f)
        val overlaySettings = StaticOverlaySettings.Builder()
            .setOverlayFrameAnchor(0f, 0f)
            .setBackgroundFrameAnchor(anchorX, anchorY)
            .setScale(widthFraction.coerceIn(0.10f, 0.42f), (widthFraction * 0.40f).coerceIn(0.06f, 0.20f))
            .setAlphaScale(1f)
            .build()
        val patchOverlay = BitmapOverlay.createStaticBitmapOverlay(patch, overlaySettings)
        val overlayEffect = OverlayEffect(ImmutableList.of(patchOverlay))
        val editedItem = EditedMediaItem.Builder(MediaItem.fromUri(inputUri))
            .setEffects(Effects(ImmutableList.of(), ImmutableList.of(overlayEffect)))
            .build()
        val transformer = Transformer.Builder(context)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: androidx.media3.transformer.Composition, exportResult: ExportResult) {
                    try {
                        val values = ContentValues().apply {
                            put(MediaStore.Video.Media.DISPLAY_NAME, "MarkAway_Masked_${System.currentTimeMillis()}.mp4")
                            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/MarkAway")
                            put(MediaStore.MediaColumns.IS_PENDING, 1)
                        }
                        val uri = context.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                            ?: throw IllegalStateException("Could not create output video")
                        try {
                            val stream = context.contentResolver.openOutputStream(uri)
                                ?: throw IllegalStateException("Could not open output video")
                            stream.use { target -> out.inputStream().use { source -> source.copyTo(target) } }
                            val publish = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
                            if (context.contentResolver.update(uri, publish, null, null) <= 0) {
                                throw IllegalStateException("Could not publish output video")
                            }
                        } catch (e: Exception) { context.contentResolver.delete(uri, null, null); throw e }
                        out.delete()
                        patch.recycle()
                        onDone(true, "Saved to Movies/MarkAway. Watermark area was masked, not AI-reconstructed.")
                    } catch (e: Exception) {
                        out.delete(); patch.recycle()
                        onDone(false, "Save failed: ${e.localizedMessage ?: "unknown error"}")
                    }
                }
                override fun onError(composition: androidx.media3.transformer.Composition, exportResult: ExportResult, exportException: ExportException) {
                    out.delete(); patch.recycle()
                    onDone(false, "Video processing failed: ${exportException.localizedMessage ?: "unsupported video"}")
                }
            })
            .build()
        onProgress("Processing video frames offline…")
        transformer.start(editedItem, out.absolutePath)
    } catch (e: Exception) {
        outputFile?.delete()
        onDone(false, "Could not start processing: ${e.localizedMessage ?: "unknown error"}")
    }
}
