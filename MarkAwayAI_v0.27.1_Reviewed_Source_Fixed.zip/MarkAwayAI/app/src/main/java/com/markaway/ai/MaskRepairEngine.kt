package com.markaway.ai

import android.graphics.Bitmap
import kotlin.math.max
import kotlin.math.min

/**
 * Manual-mask patch repair (non-neural).
 *
 * mask: same dimensions as source; opaque/white pixels mark the area to repair.
 * This is a simple local interpolation method, not AI inpainting. It is best
 * for small marks over smooth backgrounds and can produce artifacts on detail.
 */
object MaskRepairEngine {
    fun repair(source: Bitmap, mask: Bitmap): Bitmap {
        require(source.width == mask.width && source.height == mask.height) {
            "Mask dimensions must match the source image"
        }
        val w = source.width
        val h = source.height
        if (w < 3 || h < 3) return source.copy(Bitmap.Config.ARGB_8888, true)

        val src = IntArray(w * h)
        val msk = IntArray(w * h)
        source.getPixels(src, 0, w, 0, 0, w, h)
        mask.getPixels(msk, 0, w, 0, 0, w, h)
        val out = src.copyOf()

        // Fill masked pixels from the nearest unmasked pixels in four directions.
        // Reuse the sample buffer to avoid allocating an IntArray for every pixel.
        val samples = IntArray(4)
        val maxRadius = max(4, min(32, max(w, h) / 40))
        for (y in 0 until h) {
            for (x in 0 until w) {
                val idx = y * w + x
                if (((msk[idx] ushr 24) and 0xff) < 24 ||
                    ((msk[idx] and 0xff) < 32)) continue

                var count = 0
                for (dir in 0..3) {
                    var found = false
                    for (r in 1..maxRadius) {
                        val sx = when (dir) { 0 -> x-r; 1 -> x+r; else -> x }
                        val sy = when (dir) { 2 -> y-r; 3 -> y+r; else -> y }
                        if (sx !in 0 until w || sy !in 0 until h) break
                        val si = sy * w + sx
                        val alpha = (msk[si] ushr 24) and 0xff
                        val strength = msk[si] and 0xff
                        if (alpha < 24 || strength < 32) {
                            samples[count++] = src[si]
                            found = true
                            break
                        }
                    }
                    if (!found) { /* use available directions only */ }
                }
                if (count > 0) {
                    var a=0; var r=0; var g=0; var b=0
                    for (i in 0 until count) {
                        val c=samples[i]
                        a += (c ushr 24) and 0xff
                        r += (c ushr 16) and 0xff
                        g += (c ushr 8) and 0xff
                        b += c and 0xff
                    }
                    out[idx] = ((a/count) shl 24) or ((r/count) shl 16) or
                        ((g/count) shl 8) or (b/count)
                }
            }
        }
        return Bitmap.createBitmap(out, w, h, Bitmap.Config.ARGB_8888)
    }
}
