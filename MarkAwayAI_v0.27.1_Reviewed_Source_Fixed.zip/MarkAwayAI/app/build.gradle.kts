plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.markaway.ai"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.markaway.ai"
        minSdk = 26
        targetSdk = 35
        versionCode = 28
        versionName = "0.27.1"
    }
    buildFeatures { compose = true; buildConfig = true }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.activity:activity-compose:1.10.0")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.media3:media3-transformer:1.5.1")
    implementation("androidx.media3:media3-effect:1.5.1")
    implementation("androidx.media3:media3-common:1.5.1")
    // FFmpegKit-compatible maintained Android runtime: frame extraction, audio remux and MP4 encoding.
    implementation("dev.ffmpegkit-maintained:ffmpeg-kit-full:8.1.7")
    // LiteRT CompiledModel runtime for the MI-GAN inpainting model.
    implementation("com.google.ai.edge.litert:litert:2.4.0")
    implementation("com.google.ai.edge.litert:litert-gpu:2.4.0")
    debugImplementation("androidx.compose.ui:ui-tooling")
}
