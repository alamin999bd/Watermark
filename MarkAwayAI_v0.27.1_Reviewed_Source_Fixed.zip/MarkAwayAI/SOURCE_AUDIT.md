# MarkAway AI — Source Audit (v0.27.1)

## Reviewed and updated
- Archive structure, Android manifest, Gradle configuration, and GitHub Actions workflow.
- Gallery search/filter/open/share/delete/refresh source paths.
- Text/logo watermark controls and image save path.
- Settings version display now reads generated BuildConfig metadata.
- Reduce Motion now disables home-card entrance movement and decorative icon rotation, and page transitions use a short fade.
- Video export now writes to a pending MediaStore row and publishes only after successful copy; failed writes remove the incomplete row.

## Current project facts
- Application ID: `com.markaway.ai`.
- Version: `0.27.1`, version code: `28`.
- Minimum SDK 26; compile/target SDK 35.
- Gallery queries `Pictures/MarkAway/` and `Movies/MarkAway/`, capped at 200 newest items per collection per refresh.
- Image exports target `Pictures/MarkAway`; masked video exports target `Movies/MarkAway`.
- GitHub Actions runs `assembleDebug` and uploads a debug APK artifact.
- No broad storage permission is declared; media selection uses Android document pickers.

## Not implemented / not verified
- AI inpainting: no `.tflite` model is bundled; current brush repair is basic local interpolation, not AI.
- Video AI source pipeline: FFmpeg frame extraction, per-frame MI-GAN repair, MP4 encoding and audio remux are now wired. The fixed mask is stationary for the full clip; moving-watermark tracking/keyframes are not implemented. Runtime model compatibility and quality are not yet verified.
- Automatic edge detection/perspective correction: not implemented.
- No Gradle Wrapper is included; CI installs Gradle 8.9.
- No automated unit/instrumentation test suite is included.
- Android build and physical-device runtime tests have not been executed in this environment.

## Required release verification
1. Push the project folder contents to the repository root.
2. Run Actions → Build MarkAway AI APK and confirm `assembleDebug` succeeds.
3. Download and install the debug APK on Android 8+.
4. Test image import/export, text/logo watermark placement, video text export, gallery search/filter/open/share/delete/refresh, settings persistence, Reduce Motion, and back navigation.
5. Do not describe AI removal as verified until CI build, model inference and real-device export tests pass. Do not claim moving-watermark tracking or automatic edge detection.


## v0.25.0 verification additions
- A local/CI shell script checks required project files, Android manifest XML, version metadata consistency, and explicit documentation of deferred features.
- This is static source validation only; it does not replace Gradle compilation, emulator tests, or physical-device verification.


## v0.25.0 changes
- Manual repair preview uses aspect-fit rendering and matching normalized brush coordinates; letterbox margins are not paintable.
- Pointer input reads current strokes without restarting the gesture on every recomposition.
- Image export checks MediaStore publish result and deletes failed pending rows.
- Video export startup exceptions clean up the exact temporary file.
- Static source verification includes regression guards for these changes.


## v0.25.0 CI correction
- Fixed stale CI version checks and removed invalid assumptions about version strings being embedded in workflow YAML.
- Static checks pass locally; no Android SDK/Gradle installation is available here, so APK compilation remains unverified.

## Follow-up audit — 25 Nov 2026
The earlier audit found only a model-loader foundation. The subsequent update added a dedicated MI-GAN LiteRT engine, connected it to the Repair action, and added a GitHub Actions model-download step. The build workflow and actual inference have not yet been run, so this is integrated source code awaiting build/device verification.


## 25 Nov 2026 — MI-GAN build integration update
- Added a GitHub Actions step to fetch the published MI-GAN model asset into the Android assets directory before Gradle build; it fails if download fails or the file is suspiciously small.
- Connected the Repair action to the LiteRT MI-GAN engine and moved inference/save work to an IO coroutine so the UI thread is not blocked.
- Added explicit cleanup for LiteRT tensor buffers and temporary bitmaps.
- The workflow has not been run in GitHub in this session. No Gradle compilation, APK build, or physical-device test is claimed.


## v0.27.1 video feature review
- Added Media3 BitmapOverlay mosaic masking with user-adjustable fixed position and size.
- Video watermark removal (masking edition) is now present in the source.
- This is visual concealment only, not AI inpainting or moving-watermark tracking.
- Static checks do not prove Android compilation or device playback/export.


## v0.27.1 source changes
- Added `VideoAiRemovalEngine.kt`: FFmpeg frame extraction, per-frame MI-GAN reconstruction, MP4 encoding and audio remux.
- Replaced the active Video panel export action with the AI frame-processing pipeline.
- Added a 20-second clip limit and stationary mask notice.
- Build, MI-GAN tensor/GPU validation, audio sync, output quality and Samsung Galaxy M12 tests remain pending.


## Dependency and model pin review — 25 Nov 2026
- Pinned the MI-GAN model download to reviewed Hugging Face revision `179a35d8e8a518f6253f9c42fc9b412c6438cf7c`; the model card reports a 16.3 MB FP16 model and MIT license.
- Changed LiteRT runtime and GPU accelerator coordinates to `2.4.0`, and Kotlin Android/Compose plugins to `2.4.21` to avoid the known Kotlin metadata incompatibility of newer LiteRT artifacts with the previous Kotlin `2.0.21` compiler.
- Updated this audit to the actual Gradle version code `28`.
- These are dependency/source corrections only. Gradle resolution, Kotlin compilation, model inference and device tests remain pending.
