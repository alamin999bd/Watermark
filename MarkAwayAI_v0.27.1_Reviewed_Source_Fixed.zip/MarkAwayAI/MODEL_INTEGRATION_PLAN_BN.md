# MarkAway AI — AI Model Integration Plan (v0.25.0)

## Current verified state
- `LiteRtMiganInpaintingEngine.kt` implements the published MI-GAN 512×512 LiteRT `CompiledModel` input/output contract.
- The Repair action calls this engine and runs inference/save work on an IO coroutine.
- GitHub Actions downloads `migan_fp16.tflite` into Android assets before building. This workflow has not yet been run, so the model download and Android build are unverified.
- `MaskRepairEngine.kt` remains a basic local interpolation algorithm and is no longer the Repair action's selected AI path.
- The model processes a centered 512×512 square crop; it does not yet preserve all non-square image areas through a full-resolution tiled pipeline.
- The candidate's published Android benchmark is on a Pixel 8a, not the project's target Samsung Galaxy M12. GPU compatibility/performance on that phone is unknown.

## Required verification before calling AI removal complete
1. Run the GitHub Actions workflow and confirm the model download, dependency resolution, Kotlin compilation, and APK artifact succeed.
2. Install the APK on the Samsung Galaxy M12 and test GPU initialization, image inference, memory use, thermal behavior, latency, and output quality.
3. Test mask polarity, image orientation, non-square images, large images, and save failures.
4. If GPU execution fails on the target phone, evaluate a supported fallback without blocking the UI.

## Video Watermark Removal is a separate feature
A correct video pipeline needs frame decoding, a per-frame or tracked mask, inpainting, frame timing/audio preservation, and a safe export pipeline. Reusing the current text-overlay export is not removal. Do not mark this feature complete until the output video has been decoded and visually/audio checked.

## Release gate
- Do not enable an AI button that silently runs the basic interpolation engine.
- Do not claim AI image removal or video removal until model inference and end-to-end tests pass.
- APK compilation and physical-phone testing remain pending. The user must install and test the APK on their own device; this environment has not performed a physical-device test.

## References assessed (25 Nov 2026)
- MI-GAN LiteRT model card: https://huggingface.co/litert-community/MI-GAN-512-Places2-LiteRT
- MI-GAN model/runtime notes: https://github.com/john-rocky/LiteRT-Models/tree/main/migan
- Official MI-GAN research implementation: https://github.com/Picsart-AI-Research/MI-GAN


## Implementation progress (25 Nov 2026)
- Added LiteRT 2.4.0 and GPU runtime dependencies. Official Android docs list CompiledModel as the modern inference API and provide the Gradle coordinate; the MI-GAN card documents GPU CompiledModel usage.
- Added a dedicated engine adapter with the documented 4-channel NCHW input, output range, center-crop/512 resize, and compositing that preserves unmasked pixels.
- The engine is now wired to the Repair action; inference and saving run on an IO coroutine. The action checks that the model asset is bundled before starting.
- The model file could not be fetched in this environment because outbound DNS/network access failed. GitHub Actions now downloads it at build time; this workflow step has not yet been run. Do not create a dummy/empty `.tflite` file.


## CI মডেল ডাউনলোড ব্যবস্থা

GitHub Actions build শুরু হওয়ার আগে Hugging Face-এর MI-GAN model repository থেকে `migan_fp16.tflite` ডাউনলোড করার ধাপ যোগ করা হয়েছে। ফাইলটি Git repository-তে commit করতে হবে না; CI build-এর সময় `app/src/main/assets/models/`-এ রাখা হবে। ডাউনলোড ব্যর্থ হলে বা ফাইলের আকার 10 MB-এর কম হলে build থেমে যাবে—ভুল/খালি model দিয়ে APK তৈরি হবে না। এটি GitHub-hosted runner-এ network access ও model host সচল থাকার ওপর নির্ভরশীল।
