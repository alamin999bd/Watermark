## 0.26.0
- Added video watermark-area masking with adjustable horizontal/vertical position and cover size.
- Added offline MP4 export through Media3 Transformer.
- Important limitation: mosaic masking conceals the selected area; it is not AI background reconstruction and does not track moving watermarks.
- Bumped version to 0.26.0 / version code 26.

## 0.25.0
- Fixed stale GitHub Actions version/documentation validation that would fail CI after the 0.24.0 update.
- Removed invalid workflow checks that looked for Gradle version declarations inside YAML.
- Synchronized app version, source verification, docs, and APK artifact name to 0.25.0 / version code 25.
- Static checks pass; Android build and device tests remain pending.

# Changelog

## 0.24.0
- Fixed the manual repair canvas to preserve image aspect ratio and align brush coordinates with the actual displayed image.
- Ignored brush touches in letterboxed margins and stabilized pointer input across recompositions.
- Verified MediaStore image publication and removed incomplete rows when publication fails.
- Cleaned up the exact temporary video output file when export startup fails.
- Added source-level regression guards and synchronized version metadata to `0.24.0` / version code `24`.
- Android compilation, APK build, and physical-device tests remain pending.


## 0.23.0
- Synchronized project version metadata to `0.23.0` / version code `23`.
- Added `tools/verify_source.sh` for repeatable source, manifest, version, and limitation checks.
- GitHub Actions now runs source verification before attempting `assembleDebug`.
- Added a Bengali feature-status report distinguishing implemented, unverified, and not-implemented capabilities.
- No AI model, video-removal pipeline, or automatic edge-detection implementation was fabricated.
- Android build and physical-device testing remain pending.


## 0.20.0
- Added a live text watermark overlay to the image editor preview.
- Center-aligned the saved text watermark horizontally to match the preview placement.
- Improved video export cleanup: incomplete MediaStore entries are deleted if copying the exported file fails.
- Clear stale image/logo preview state before loading a newly selected file.
- Build and device testing remain pending; no successful APK build is claimed.


## 0.19.0
- Reviewed source archive structure, manifest, Gradle configuration, GitHub Actions workflow, and My Gallery query.
- Confirmed My Gallery is scoped to MarkAway export folders and caps each media collection at 200 newest entries.
- Updated app version metadata to 0.19.0 (version code 19).
- Build and physical-device testing remain pending; no successful APK build is claimed.

# Changelog

## 0.18.0
- Synchronized app version metadata and project documentation.
- Reviewed GitHub Actions debug-build workflow and documented build verification expectations.
- AI inpainting and video watermark removal remain deferred and are not implemented.
- No Android build or physical-device test is claimed for this update.

## 0.17.0
- Wired the Reduce motion setting into page transitions: reduced-motion mode uses a short fade without horizontal sliding.
- Limited each My Gallery media query to the newest 200 matching items to prevent unbounded gallery loading on devices with large media libraries.
- AI inpainting and video watermark removal remain deferred and are not implemented.

## 0.16.0
- Added a Settings screen accessible from the home screen.
- Added persistent accent selection (Violet, Blue, Emerald) for Material controls.
- Added a persistent Reduce motion preference toggle; note that not every decorative animation is currently suppressed.
- Added app version, export-folder, and feature-limitation information to About.
- AI inpainting and video watermark removal remain deferred and are not implemented.

## 0.15.0
- Added staggered-feel entrance motion to Home feature cards using fade, vertical slide, and expand animations.
- Added a subtle repeating rotation animation to feature icons.
- Kept the existing page transition and all existing editor/gallery behavior.
- AI inpainting and video watermark removal remain deferred and are not implemented.

## 0.14.0
- Added logo watermark rotation control (-180° to 180°).
- Preview and saved output use the same rotation.
- Reset restores logo position, size, and rotation.
- AI inpainting and video watermark removal remain deferred.


## 0.13.0
- Added search by exported media filename in My Gallery.
- Added All / Images / Videos filters for the app's own exported media.
- Added visible result count and a helpful empty-filter state.
- AI inpainting and video watermark removal remain deferred and are not implemented.


## 0.12.0
- Added share actions for media exported by MarkAway in My Gallery.
- Added delete actions for MarkAway gallery items using their MediaStore URIs.
- Gallery refreshes after a delete attempt and reports the result.
- No broad storage permission added; actions are limited to the app's own exported media list.


## 0.10.0
- Added an Undo action to remove the most recent mask stroke.
- Added clearer mask reset controls and improved repair action layout.
- Optimized the basic repair loop to reuse temporary sample memory instead of allocating per pixel.
- Hardened the GitHub Actions build workflow with file checks and build concurrency.
- AI inpainting and video watermark removal remain out of scope until a compatible, licensed model and frame pipeline are integrated and tested.

## 0.9.0
- Added My Gallery for viewing and opening images/videos exported by MarkAway.
- Gallery queries only the app's own `Pictures/MarkAway` and `Movies/MarkAway` folders.
- Added Android back navigation from tool screens to the home screen.
- Updated project documentation with feature status and limitations.

## 0.8.0
- Premium dark Compose UI and animated page transitions.
- Image text watermark and logo watermark tools.
- Video text watermark export.
- Manual brush mask and basic local repair foundation.
- GitHub Actions debug APK workflow.

## 0.11.0
- Added image text watermark size control.
- Added image text watermark opacity control.
- Disabled Apply & Save until an image and non-empty watermark text are available.
- Kept AI inpainting and video watermark removal explicitly marked as not implemented.


## 0.21.0
- Corrected version metadata and CI validation.
- Hardened image saving with MediaStore pending state and cleanup on failure.
- Updated source audit and release test checklist.
- No AI/video watermark-removal implementation is claimed.


## 0.22.0
- Settings screen now displays the actual app version from BuildConfig.
- Reduce Motion now suppresses home-card movement and decorative icon rotation.
- Video export uses MediaStore pending publication and removes incomplete output on failure.
- Synchronized documentation and CI version checks.
- AI removal, video removal, and automatic edge detection remain deferred and clearly documented.

## 0.27.1
- Added experimental offline frame-by-frame MI-GAN video watermark reconstruction with FFmpeg frame decode/MP4 encode/audio remux.
- Reused the compiled MI-GAN model between frames and enabled full-frame mask positioning.
- Added 20-second clip limit and documented stationary-mask limitation. Build and physical-device validation pending.
