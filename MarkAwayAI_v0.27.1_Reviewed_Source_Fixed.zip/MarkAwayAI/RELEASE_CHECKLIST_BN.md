# MarkAway AI v0.27.1 — Release Checklist

## Source / Build
- [ ] GitHub Actions source verification succeeds.
- [ ] Gradle dependency resolution succeeds.
- [ ] `assembleDebug` succeeds.
- [ ] Artifact `MarkAwayAI-debug-apk-v0.27.1` downloads.
- [ ] APK installs and launches.
- [ ] Version `0.27.1`, versionCode `28` confirmed.

## Image
- [ ] JPG/PNG import and save.
- [ ] Text watermark preview/save.
- [ ] Logo position/size/rotation/opacity.
- [ ] Manual interpolation repair.
- [ ] MI-GAN model loads and image inference succeeds on device.

## Video AI
- [ ] FFmpeg frame extraction succeeds.
- [ ] MI-GAN inference succeeds for each frame.
- [ ] MP4 encode and source audio mapping succeed.
- [ ] Output duration, orientation, playback and A/V sync verified.
- [ ] Center/corner stationary masks tested.
- [ ] Memory use, performance, and cleanup checked.
- [ ] 20-second duration limit enforced.
- [ ] Moving-watermark tracking remains explicitly unsupported.

## Gallery / Stability
- [ ] Gallery search/filter/refresh/open/share/delete.
- [ ] Settings persistence and Back navigation.
- [ ] Physical Android device test and crash/log review.

## Deferred
- Automatic moving-watermark tracking/keyframes.
- Automatic edge detection/perspective correction.

Do not call this a verified release until CI build and physical-device tests pass.
