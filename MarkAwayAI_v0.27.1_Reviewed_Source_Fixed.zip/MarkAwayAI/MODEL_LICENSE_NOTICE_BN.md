# MI-GAN model license and attribution

প্রস্তাবিত মডেল: `litert-community/MI-GAN-512-Places2-LiteRT`

- Model file: `migan_fp16.tflite` (প্রায় 16.3 MB)
- Model repository-তে license হিসেবে MIT ঘোষণা করা আছে।
- Attribution: Copyright (c) 2024 Picsart AI Research (PAIR)
- Model repository: https://huggingface.co/litert-community/MI-GAN-512-Places2-LiteRT
- Original research implementation: https://github.com/Picsart-AI-Research/MI-GAN
- MIT notice অ্যাপের `app/src/main/assets/licenses/MI-GAN-MIT.txt`-এ রাখা হয়েছে।

GitHub Actions build-এর সময় Hugging Face repository থেকে model asset আনা হয়। Model repository বা upstream licensing বদলালে release-এর আগে আবার license যাচাই করতে হবে।
