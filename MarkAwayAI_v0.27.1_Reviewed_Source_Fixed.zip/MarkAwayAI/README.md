# MarkAway AI — Android project

**Version:** 0.27.1 (development source)  
**Version code:** 28  
**Application ID:** `com.markaway.ai`  
**Minimum Android:** 8.0 (API 26)  
**Compile/Target SDK:** 35

MarkAway AI is an offline-first Android media utility. The project does not require a paid API, domain, account, or subscription for its local processing flow.

## Included source features

- Jetpack Compose dark UI.
- Add text/logo watermarks to images.
- Manual brush mask repair using basic interpolation (not AI).
- MI-GAN LiteRT image-inpainting source integration; model is downloaded during CI build.
- Experimental frame-by-frame video inpainting source pipeline using FFmpeg + MI-GAN.
- Exported-media gallery, search/filter, open/share/delete.
- Settings preferences.

## Video AI limitations

- Maximum input clip duration: 20 seconds.
- One fixed selected region is repaired throughout the clip.
- No automatic moving-watermark tracking or keyframes.
- Frame rate is capped at 30 FPS and output width at 1280 px.
- Model tensor compatibility, GPU inference, memory/performance, audio sync, and output quality still require build and real-device validation.

## Verification status

The supplied archive passed ZIP integrity validation and `tools/verify_source.sh` static checks. This is not an Android compile test. No APK build, MI-GAN inference test, or physical-device test has been completed in this review environment.

## Build using GitHub Actions

1. Extract this ZIP.
2. Upload the **contents inside the `MarkAwayAI/` folder** to the repository root (do not upload the outer folder as a nested directory).
3. Keep `.github/workflows/android.yml`.
4. Open GitHub → Actions → **Build MarkAway AI APK**.
5. Run the workflow or push to `main`.
6. Only if the workflow succeeds, download artifact `MarkAwayAI-debug-apk-v0.27.1` and extract `app-debug.apk`.

The workflow downloads the MI-GAN model before building. A successful static check alone does not mean the APK build succeeded.

## Local build requirements

- JDK 17
- Gradle 8.9
- Android SDK Platform 35

Build command from the project root:

```bash
gradle --no-daemon clean assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.
