# MarkAway AI v0.25.0 — Phone Test Report

- Device: Samsung Galaxy M12 / অন্য: __________
- Android version: __________
- GitHub Actions build: PASS / FAIL
- APK install: PASS / FAIL

| # | পরীক্ষা | PASS / FAIL / NOT TESTED | সমস্যা / নোট |
|---|---|---|---|
| 1 | অ্যাপ চালু ও Back navigation | | |
| 2 | JPG Import | | |
| 3 | PNG Import | | |
| 4 | বড় ছবি Import | | |
| 5 | Text Watermark Preview / Save | | |
| 6 | Text size ও opacity | | |
| 7 | Logo Watermark / Save | | |
| 8 | Logo position / size / rotation / opacity | | |
| 9 | Portrait ও landscape preview ratio | | |
| 10 | Brush / mask | | |
| 11 | Letterbox margin-এ brush না আঁকা | | |
| 12 | Long stroke / Undo / Clear | | |
| 13 | Manual Repair / Save | | |
| 14 | Video Import / Text Watermark / Export | | |
| 15 | Failed export-এ অসম্পূর্ণ ফাইল না থাকা | | |
| 16 | Gallery Search / Filter / Refresh | | |
| 17 | Gallery Open / Share / Delete | | |
| 18 | Settings / Accent / Reduce Motion | | |
| 19 | দীর্ঘ ব্যবহারে Crash / Freeze | | |

## Failed test details
- কোন ধাপ নম্বর: __________
- কী চাপার পর সমস্যা হয়েছে: __________
- কী হওয়ার কথা ছিল: __________
- আসলে কী হয়েছে: __________
- Screenshot / GitHub log: __________
