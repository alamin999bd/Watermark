# MarkAway AI — ফিচার স্ট্যাটাস (v0.27.1)

এই রিপোর্ট ZIP-এর সোর্স কোড, Gradle কনফিগারেশন এবং GitHub Actions workflow দেখে তৈরি। Static verification সফল হয়েছে। Android APK build, MI-GAN inference এবং বাস্তব ফোন পরীক্ষা এখনো করা হয়নি।

## সোর্সে বাস্তবায়িত

- Image Text Watermark: ছবিতে লেখা যোগ করে সংরক্ষণ।
- Image Logo Watermark: লোগো বসানো, অবস্থান/আকার/rotation/opacity নিয়ন্ত্রণ।
- Manual Image Repair: Brush mask ও সাধারণ interpolation repair। এটি AI নয়।
- AI Image Inpainting source: `LiteRtMiganInpaintingEngine.kt`-এ MI-GAN LiteRT inference adapter আছে; GitHub Actions build-এর সময় model ডাউনলোড করার ধাপ আছে। কার্যকারিতা build ও ফোনে পরীক্ষা বাকি।
- Video AI source pipeline: `VideoAiRemovalEngine.kt`-এ FFmpeg দিয়ে frame extraction, প্রতিটি frame-এ MI-GAN repair, MP4 encode এবং source audio map করার কোড আছে।
- Video UI: নির্বাচিত স্থির জায়গা (fixed region) ভিডিওর প্রতিটি frame-এ repair করার জন্য পাঠায়।
- Gallery: MarkAway export-এর image/video listing, search/filter, open/share/delete/refresh।
- Settings: Accent preference ও Reduce Motion preference।

## Video AI-এর সীমাবদ্ধতা

- একবারে সর্বোচ্চ ২০ সেকেন্ডের clip।
- একই mask position পুরো ভিডিওতে ব্যবহৃত হয়; moving watermark tracking/keyframes নেই।
- FPS সর্বোচ্চ ৩০-এ সীমাবদ্ধ; output width সর্বোচ্চ ১২৮০ px।
- Model tensor compatibility, GPU support, memory use, audio sync, output quality এবং M12-এ performance এখনো যাচাই হয়নি।
- এই কোড থাকলেই AI ফলাফল ভালো হবে—এমন নিশ্চয়তা নেই।

## Build ও test অবস্থা

- ZIP integrity: PASS
- `tools/verify_source.sh`: PASS (static checks only)
- Android Gradle compilation: NOT TESTED (এই environment-এ Gradle/Android SDK নেই)
- APK generation: NOT TESTED
- MI-GAN model inference: NOT TESTED
- Samsung Galaxy M12 physical-device test: NOT TESTED

## এখনো নেই

- Automatic watermark motion tracking/keyframes।
- Automatic edge detection ও perspective correction।
- বাস্তব ফোনে যাচাই করা release APK।

**সততা নোট:** Source-level implementation-কে সফল APK build বা tested AI feature হিসেবে গণ্য করা যাবে না।
