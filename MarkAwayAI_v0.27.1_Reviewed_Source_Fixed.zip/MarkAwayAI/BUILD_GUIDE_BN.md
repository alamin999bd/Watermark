# MarkAway AI v0.27.1 — GitHub থেকে APK Build

## Repository-তে Source Upload

1. ZIP Extract করো।
2. Extract করা `MarkAwayAI` ফোল্ডারের **ভেতরের সব ফাইল ও ফোল্ডার** GitHub repository-এর root-এ upload করো।
3. `.github/workflows/android.yml` অবশ্যই রাখতে হবে।
4. Root-এ `settings.gradle.kts`, `build.gradle.kts`, `app/`, `tools/` এবং `.github/` থাকবে। অতিরিক্ত `MarkAwayAI/MarkAwayAI/` nested folder তৈরি করবে না।

## Build চালানো

1. GitHub repository খুলে **Actions** চাপো।
2. **Build MarkAway AI APK** নির্বাচন করো।
3. **Run workflow** চাপো, অথবা `main` branch-এ source push করো।
4. Workflow শেষ হওয়া পর্যন্ত অপেক্ষা করো।
5. সব ধাপ Success হলে Artifact `MarkAwayAI-debug-apk-v0.27.1` ডাউনলোড করো।
6. Artifact ZIP Extract করে `app-debug.apk` ইনস্টল করো।

## Build ব্যর্থ হলে

GitHub Actions run খুলে প্রথম failed step-এর log দেখো। বিশেষ করে dependency resolve, model download, `tools/verify_source.sh`, Kotlin compile এবং APK output ধাপ পরীক্ষা করো।

**গুরুত্বপূর্ণ:** Static source verification পাস মানেই APK build পাস নয়। APK তৈরি হলেও MI-GAN inference ও ভিডিও export বাস্তব ফোনে পরীক্ষা না করা পর্যন্ত AI feature-কে verified বলা যাবে না।
