#!/usr/bin/env bash
set -euo pipefail
required=(
  "settings.gradle.kts"
  "build.gradle.kts"
  "app/build.gradle.kts"
  "app/src/main/AndroidManifest.xml"
  "app/src/main/java/com/markaway/ai/MainActivity.kt"
  "app/src/main/java/com/markaway/ai/LiteRtMiganInpaintingEngine.kt"
  "app/src/main/java/com/markaway/ai/VideoAiRemovalEngine.kt"
  "PROJECT_DOCS.md"
  "SOURCE_AUDIT.md"
  "RELEASE_CHECKLIST_BN.md"
)
for file in "${required[@]}"; do
  test -s "$file" || { echo "Missing or empty required file: $file" >&2; exit 1; }
done

grep -q 'versionCode = 28' app/build.gradle.kts
grep -q 'versionName = "0.27.1"' app/build.gradle.kts
grep -q 'Current version: `0.27.1`' PROJECT_DOCS.md
grep -q 'Current version code: `28`' PROJECT_DOCS.md
grep -q 'VideoAiRemovalEngine.start' app/src/main/java/com/markaway/ai/MainActivity.kt
grep -q 'FFmpegKit.execute' app/src/main/java/com/markaway/ai/VideoAiRemovalEngine.kt
grep -q 'FFprobeKit.execute' app/src/main/java/com/markaway/ai/VideoAiRemovalEngine.kt
grep -q 'LiteRtMiganInpaintingEngine.repair' app/src/main/java/com/markaway/ai/VideoAiRemovalEngine.kt
grep -q 'MAX_CLIP_SECONDS = 20.0' app/src/main/java/com/markaway/ai/VideoAiRemovalEngine.kt
grep -q 'dev.ffmpegkit-maintained:ffmpeg-kit-full:8.1.7' app/build.gradle.kts
grep -q 'com.google.ai.edge.litert:litert:2.4.0' app/build.gradle.kts
grep -q 'com.google.ai.edge.litert:litert-gpu:2.4.0' app/build.gradle.kts
grep -q 'version \"2.4.21\"' build.gradle.kts
grep -q 'version code: `28`' SOURCE_AUDIT.md
grep -q 'Automatic edge detection' SOURCE_AUDIT.md
grep -q 'pointerInput(sourceBitmap)' app/src/main/java/com/markaway/ai/MainActivity.kt
grep -q 'Could not publish saved image' app/src/main/java/com/markaway/ai/MainActivity.kt

python3 - <<'PY'
import xml.etree.ElementTree as ET
ET.parse('app/src/main/AndroidManifest.xml')
print('AndroidManifest.xml: valid XML')
PY

echo 'Source verification passed (static checks only).'

grep -q 'MarkAwayAI-debug-apk-v0.27.1' .github/workflows/android.yml
