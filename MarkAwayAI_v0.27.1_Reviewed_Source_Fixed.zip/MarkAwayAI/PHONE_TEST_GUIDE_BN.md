# MarkAway AI v0.27.1 — ফোনে পরীক্ষা

APK শুধু GitHub Actions Build সফল হলে পাওয়া যাবে। APK install হওয়া মানেই সব feature ঠিক—এমন নয়।

## ১. Install ও basic test

- [ ] APK install হয় এবং app চালু হয়।
- [ ] Settings/About-এ Version `0.27.1`, Version Code `28` দেখা যায় (যদি দেখানো হয়)।
- [ ] Back navigation কাজ করে।

## ২. Image test

- [ ] JPG ও PNG import হয়।
- [ ] Text watermark যোগ ও save হয়।
- [ ] Logo watermark-এর position, size, rotation ও opacity কাজ করে।
- [ ] Manual brush repair save হয় (এটি interpolation, AI নয়)।
- [ ] AI Image Repair চালালে model load হয়, crash হয় না এবং output তৈরি হয়।

## ৩. Video AI test

প্রথমে ছোট, সাধারণ test clip ব্যবহার করো; ব্যক্তিগত ভিডিও প্রয়োজন নেই।

- [ ] ৫ সেকেন্ডের clip import হয়।
- [ ] Fixed watermark region সঠিকভাবে নির্বাচন করা যায়।
- [ ] MI-GAN model load হয় এবং GPU/runtime crash হয় না।
- [ ] Frame processing সম্পন্ন হয়।
- [ ] MP4 output Movies/MarkAway-তে save হয়।
- [ ] Output-এর duration ও audio/video sync ঠিক থাকে।
- [ ] Video সঠিক orientation-এ চলে।
- [ ] Center এবং corner-এ stationary watermark পরীক্ষা করা হয়।

সীমাবদ্ধতা: সর্বোচ্চ ২০ সেকেন্ড; fixed region; moving-watermark tracking নেই। ফোনের performance, heat ও memory use লক্ষ্য করো। সমস্যা হলে পরীক্ষা বন্ধ করে error লিখে রাখো।

## ৪. Gallery ও Settings

- [ ] Gallery search/filter/refresh/open/share/delete কাজ করে।
- [ ] Accent preference restart-এর পর থাকে।
- [ ] Reduce Motion preference কাজ করে।
- [ ] App crash ছাড়াই স্বাভাবিকভাবে চলে।

প্রতিটি ফল PASS / FAIL / NOT TESTED হিসেবে লিখবে। ব্যক্তিগত media পাঠানোর প্রয়োজন নেই।
