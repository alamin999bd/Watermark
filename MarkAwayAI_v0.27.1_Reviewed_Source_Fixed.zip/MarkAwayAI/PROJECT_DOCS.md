# MarkAway AI — Project maintenance notes

- Package/application ID: `com.markaway.ai`
- Current version: `0.27.1`
- Current version code: `28`
- Minimum SDK: 26 (Android 8.0)
- Compile/target SDK: 35
- UI: Kotlin + Jetpack Compose + Material 3
- Video processing: FFmpegKit-maintained 8.1.7 (frame extraction, encoding and audio mux)
- Offline inference: LiteRT MI-GAN 2.4.0; model downloaded during CI build

## Project structure

- `app/src/main/java/com/markaway/ai/MainActivity.kt` — app navigation, Compose UI, image and video editing, gallery.
- `app/src/main/java/com/markaway/ai/MaskRepairEngine.kt` — basic non-neural brush-mask repair.
- `app/src/main/java/com/markaway/ai/LiteRtMiganInpaintingEngine.kt` — MI-GAN LiteRT image/frame inference adapter.
- `app/src/main/java/com/markaway/ai/VideoAiRemovalEngine.kt` — FFmpeg frame extraction, per-frame MI-GAN repair, MP4 encode/audio mapping.
- `app/src/main/AndroidManifest.xml` — app manifest.
- `.github/workflows/android.yml` — GitHub Actions debug APK build.

## Safe update rules

1. Keep the application ID unchanged so future builds can update the same installed app when signing is handled consistently.
2. Increase `versionCode` for every distributable update and update `versionName`.
3. Preserve existing features and source files; do not replace this project with a new starter project.
4. Do not claim AI removal until a compatible, licence-checked model is bundled and tested end-to-end.
5. Test image import/export, MI-GAN inference, video frame processing/audio sync, gallery listing, and back navigation on the target Android device before calling a release stable.

## Current limitations

MI-GAN image/video inference source is integrated, but model tensor compatibility, GPU inference, CI build and physical-device behavior are not yet verified. Video AI source pipeline uses a fixed selected region for clips up to 20 seconds; moving-watermark tracking is not implemented. This source has passed static checks only; model tensor layout, GPU inference, audio sync, APK compilation and physical-device behavior are unverified. Device/build testing remains required.


## Version 0.13.0 update
- My Gallery now supports sharing an exported item through Android's share sheet.
- My Gallery now supports deleting an exported item. The list refreshes after the delete attempt.
- These actions operate on the MarkAway gallery entries returned from the app's own export folders.

## Version 0.14.0 update
- Added logo watermark rotation control from -180 to 180 degrees.
- Added rotated logo preview and applies the same rotation when exporting the watermarked image.
- Reset control now restores logo position, size, and rotation.
- AI inpainting and video watermark removal remain deferred and are not implemented.

## 0.15.0 UI update
- Home feature cards animate into view with fade/slide/expand motion.
- Feature icons use a subtle repeating rotation effect.


## 0.16.0 Settings update
- Added a Settings screen with on-device persistent accent preference (Violet, Blue, Emerald).
- Added a persistent Reduce motion preference toggle. This is currently a stored preference and does not yet disable every decorative animation.
- Added About information including app version, export folders, and current AI/video removal limitations.


## 0.17.0 Performance update
- My Gallery now caps each MediaStore collection query at the newest 200 matching items (images and videos are queried separately).
- Reduce motion now affects page transitions by replacing slide/fade motion with a short fade. Other decorative animations may still be present.
- Build and physical-device testing remain pending.


## Version 0.18.0 — source and build preparation
- Synchronized project documentation with the Gradle application version (`0.18.0`, version code `18`).
- Reviewed the GitHub Actions workflow and documented the expected repository-root layout and debug-artifact output.
- No AI inpainting or video watermark-removal implementation was added; both remain deferred as requested.
- This is source preparation only. A successful Android build and physical-device test have not been performed.


## Version 0.20.0 — source audit and build checks
- Reviewed the archive structure, manifest, Gradle configuration, GitHub Actions workflow, and gallery query implementation.
- Confirmed gallery queries are scoped to `Pictures/MarkAway/` and `Movies/MarkAway/` and load at most 200 newest entries from each collection.
- Updated project version metadata to `0.20.0` / version code `19`.
- Build remains unverified in this environment; confirm the GitHub Actions result and test on a physical Android device.
- No Gradle Wrapper is included; the workflow installs Gradle 8.9.


## Version 0.21.0 — consolidated source maintenance
- Corrected the documented version code to match Gradle (`21`).
- Updated GitHub Actions source checks for version `0.21.0` / code `21`.
- Hardened image export: MediaStore rows remain pending until the PNG is fully written; failed writes/encoding remove the incomplete row.
- Updated the source audit with implemented features, limitations, and release verification steps.
- AI inpainting, video watermark removal, and automatic edge detection remain unimplemented because this source archive contains no compatible AI model or those processing pipelines.
- Build and device testing remain pending.


## Version 0.22.0 — consolidated release-readiness update
- Synchronized Gradle, GitHub Actions, and project documentation to version `0.22.0` / code `22`.
- Settings now displays the actual build version instead of a stale hard-coded version.
- Reduce Motion now suppresses home-card entrance movement and icon rotation as well as page slide transitions.
- Video export now keeps its MediaStore item pending until the copied MP4 is fully written, publishes it only after success, and deletes incomplete rows on failure.
- AI inpainting, video watermark removal, and automatic edge detection remain unavailable: this archive has no compatible licensed model or complete processing pipeline.
- No Android SDK/Gradle executable is available in this editing environment, so compilation, APK build, and device tests remain unverified. GitHub Actions must be run before release.


## Version 0.23.0 — consolidated source verification
- Synchronized Gradle, GitHub Actions, and documentation to version `0.23.0` / code `23`.
- Added a repeatable source verification script and wired it into CI before the Android build.
- Added a Bengali feature-status document that separates implemented features, source-level checks, and items that require a model or a dedicated processing pipeline.
- AI image inpainting, video watermark removal, and automatic edge detection are still not implemented; no compatible model or tested pipeline was present in the supplied source archive.
- Android compilation, APK generation, and physical-device tests remain unverified until GitHub Actions and device checks succeed.


## Version 0.24.0 — image repair interaction and export hardening
- Fixed the manual repair canvas to preserve the source image aspect ratio instead of stretching it to the editor card.
- Brush coordinates now map to the displayed image bounds; touches in letterboxed margins are ignored.
- Stabilized drag handling so recomposition during a brush stroke does not cancel the active gesture or reuse stale stroke state.
- Image export now verifies that the MediaStore pending row was successfully published; failed publication removes the incomplete row.
- Video export startup failures now delete the exact temporary output file created for that export.
- Added static regression guards for the above source paths. These checks do not replace compilation or device testing.


## Version 0.25.0 — release workflow correction
- Corrected a CI validation mismatch: the workflow previously searched for obsolete `0.23.0` documentation strings while the project was already `0.24.0`.
- Removed invalid checks that expected Gradle version declarations to appear inside the workflow YAML.
- Synchronized project version metadata to `0.25.0` / version code `25` and updated the APK artifact name.
- Re-ran static source verification locally. Android compilation and device testing remain unverified because this environment has no Gradle executable or Android SDK.


## Version 0.26.0 — video watermark-area masking
- Added a video workflow to select a fixed watermark region, adjust horizontal/vertical position and cover size, and export a new MP4 using Media3 Transformer.
- The current video method uses a mosaic cover. It conceals the selected region; it does not recover or AI-reconstruct the background behind the watermark. Moving watermarks are not tracked.
- Bumped version metadata to `0.26.0` / version code `26`.
- Build and device compatibility still require Gradle CI and real-device testing.


## Version 0.27.0 — Video AI processing source
- Added an offline frame extraction → MI-GAN inpainting → MP4 encode/audio mux pipeline.
- Added FFmpegKit-maintained Android runtime dependency.
- The MI-GAN compiled model is reused across frames.
- The current mask is stationary across the clip. Automatic tracking/keyframes are deferred.
- Processing currently limits clips to 20 seconds and output width to 1280 px for device memory/performance.
- This is source implementation only until GitHub CI builds successfully and real-device tests confirm the model and export pipeline.
